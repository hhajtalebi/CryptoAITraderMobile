package app.cryptoaitrader.crypto_ai_trader;
import io.flutter.embedding.android.FlutterActivity;
public class MainActivity extends FlutterActivity {}
