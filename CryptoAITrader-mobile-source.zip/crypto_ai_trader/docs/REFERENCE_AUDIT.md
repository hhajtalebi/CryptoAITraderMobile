# Reference audit • 2026-10-02
Source: https://github.com/hhajtalebi/CryptoAITrader/tree/arena/01a0cf53-cryptoaitrader
Pinned commit: `1075fc9c8ed8d77e6dd24a841c5148e7ea27ce1c`.

## Inspected sources and decisions
- README_EN.md, PROJECT_PROGRESS.md: Python/Qt desktop, Kivy mobile, 2.7.0. Existing mobile is NOT reused. Reported Python test counts are upstream claims, not our test results.
- `signals/engine.py`, strategies/*, `intelligent_decision.py`: closed-candle analysis, technical vs final confidence, evidence reliability, no-trade on severe independent conflicts; high confidence is not a calibrated win probability. Dart strategy is a smaller, explicitly versioned research model, NOT an exact port of all upstream strategies.
- `signals/risk_engine.py`, position_sizing.py: correct-side SL, ATR guard, max stop distance, risk budget, RR tolerance; preserved as conservative pre-trade gates, plus fees/exposure/staleness/daily loss.
- `trading/staged_targets.py`, trade_monitor.py: 1/3 original quantity at each target, SL to entry after TP1; preserved. Breakeven price still loses fees/slippage.
- `backtest/execution.py`, walk_forward.py: next-open fills, adverse costs, stop-first ambiguous bars, chronological validation; carried into research engine. Upstream reports show no validated profitable edge; live remains hard-disabled.
- `signals/learning.py`: >=30 samples, beta shrinkage and Wilson interval; bounded evidence, not automatic deployment.
- `market/providers/lbank/{constants,parser,websocket_client}.py`: real endpoints and JSON heartbeat. Ticker REST probed successfully; kline endpoint returned 10003 for upstream interval strings in this environment. Adapter errors remain visible, never substituted with fabricated candles.
- `market/providers/toobit/{constants,parser,websocket_client}.py`: public REST and WebSocket formats; REST ticker/klines probed successfully. Default provider is Toobit.
- `market/providers/`: LBank, Toobit, Bitpin. **No KCEX adapter** in this revision. KCEX is explicitly unsupported until an official documented API and permitted access can be verified.
- `ai/providers`, `ai/agent`, `signals/prediction/*`: extensive provider/agent/prediction ecosystem. Not silently removed: parity backlog below.
- `app/security`, database/repositories, logging, `ui/`, `mobile/`: no desktop code/UI embedded. No real trading or withdrawal endpoints are included.

## Parity backlog (not claimed complete)
Full seven-strategy parity; probabilistic multi-horizon prediction, anomaly/event/cross-asset fusion; order book/CVD and BTC context; all-market scanner; autonomous/scalp/ultra/trend-ladder modes; AI tool-calling and provider ranking/Ollama management; exchange wallet sync; Bitpin; import/export/backup; desktop updater/auth/email/log center. These need independent mobile milestones and regression fixtures. Ultra/live automation is intentionally excluded from first paper build for safety, not claimed migrated.

## Mobile architecture
Feature-first Clean Architecture. Domain is pure Dart (no Flutter/network/database imports). Application orchestrates Riverpod providers and async work. Data owns typed exchange adapters, bounded HTTP, resilient WS, SQLite and Keychain/Keystore. Presentation owns only widgets and user intent.

`market → immutable candles/quotes → isolate analysis → signal → risk gate → transactional paper engine → portfolio/research`.
No exchange order-placement capability exists. SQLite transactions + unique client/event keys serialize order, partial, TP and SL effects, including process restarts. A stale/disconnected quote cannot open or close a paper order. Cached data is explicitly labelled offline. Mobile suspension is NOT background execution; missed ticks cannot be reconstructed as real fills.

## Follow-up live verification
Both exchanges passed REST ticker/candle and WebSocket probes; see `LIVE_PROBE.json`. LBank kline requires the explicit `time` start parameter in this environment; requesting from 500 intervals back returned 499 valid candles. The adapter was corrected accordingly. LBank WS `TS` was a zone-less ISO timestamp at UTC+8, verified against simultaneous REST milliseconds, not an epoch number. Explicit source-time parsing and an out-of-order quote regression guard were added; client receipt time is never substituted as exchange time.
