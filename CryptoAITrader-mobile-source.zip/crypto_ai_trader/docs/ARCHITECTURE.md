# Architecture / v0.1

```
lib/
  core/data/            SQLite bootstrap, bounded HTTP, resilient WebSocket, secure vault
  core/providers.dart   Riverpod composition root, preferences, lifecycle, repository providers
  core/presentation/    design tokens, EN/FA translations, home
  features/
    market/             domain contracts → exchange adapters/cache → controller → chart/list
    analysis/           pure indicators + signal → isolate provider → signal detail
    trading/            risk + position FSM → atomic SQLite ledger → use cases → order review
    portfolio/          account balances and event history
    research/           no-lookahead simulation, expanding folds, shrinkage/Wilson → lab
    assistant/          opt-in HTTPS research explanation, no tools/order access
    settings/           source selection, locale, secure configuration
```

## State and lifecycle
`ProviderScope` injects initialized SQLite. Riverpod owns transport/controller lifetimes; app pause tears down socket and polling, resume constructs and resubscribes. Auto-dispose analysis cancels scheduled refresh. `compute` performs indicator/signal and backtest work off the Flutter UI isolate. REST JSON decoding uses `Isolate.run`. Chart paints a bounded visible slice; no network-dependent WebView or CDN chart.

## Execution invariant
Only `PaperRepository.submit` creates an order. Transaction: idempotency lookup → mark-to-market loss deduction → account reservation → daily/portfolio risk → actual adverse fill recheck → PENDING order → OPEN position + entry fee event → COMMIT. No intermediate pending trade can be half-written. Order state mirrors position state; PENDING is an atomic internal state, not an exchange pending order. Rejected intent leaves no order; no separate cancellation/fill matching engine is claimed.

Position: `pending → open → partiallyClosed → closed`; direct `open → closed` is valid for SL/full close. TP id keys are `<position>:TP1/2/3`, SL is `<position>:SL`. Manual actions have client IDs; SQLite unique constraints plus transactions and event set guard replay. Source mark timestamps are monotonic per position. Restart reloads remaining quantity, targets reached, SL, fees and idempotency keys.

## Model / execution limits
- Signal model `mobile-v1`: EMA20/50 trend, RSI, MACD histogram, ADX regime, 20-bar S/R, higher-timeframe direction. Missing indicators, gaps, stale data, extensions and conflicting context lead to WAIT.
- Ten requested indicator families calculated; EMA20 is the chart overlay, others currently numeric on Signals. VWAP resets at UTC midnight; Stochastic is fast K and 3-bar D. ATR/ADX use Wilder initialization from first observed bar; exact upstream/pandas parity not claimed.
- Confidence is a heuristic evidence score with saturation damping, never a calibrated probability. No trained prediction output exists.
- Public spot prices are the reference for simulated long/short, not executable futures bid/ask; no funding/liquidation model. 1× notional and bounded exposure.
- 0.5% planned equity risk/trade, max 1% allowed by domain, 3% aggregate planned risk, 3% daily realized-loss gate, 5 open positions; no user controls to bypass those gates.
- 0.06% fee each fill, 0.04% adverse spread/slippage each side. Gaps may exceed planned loss.
- Only selected symbol gets tick-by-tick WS updates; other open symbols on the currently selected exchange are checked via 15-second REST snapshots. Switching exchange suspends monitoring of positions on the other exchange. No fills are invented for app-suspended or disconnected periods; re-entry uses next observed fresh price.
- Account available funds = cash net fees/realized deltas minus reserved entry notional. Risk engine also deducts open losses and does not spend unrealized gains. Opening new positions requires fresh marks for every active position.
- Backtest is a separate single-timeframe, fixed-model evaluation. Historical S/R derived only from closed history; entry next open; ambiguous stop+target bars are stop-first. Research sample is currently at most 500 fetched bars. Drawdown is closed-equity drawdown, not intratrade drawdown. Folds use expanding training statistics, no parameter optimization yet. Walk-forward is NOT proof that live MTF behavior has an edge.
- Historical edge uses beta prior 10 observations and Wilson 95% interval, minimum 30 completed R outcomes; no auto-update of model parameters or risk weights.

## Extension contracts
Add an `ExchangeGateway` implementation, normalized UTC/source data, verified symbol/timeframe mappings and recorded contract tests before registering a new venue. Never copy an undocumented web private endpoint into a trading adapter. Live order execution requires a new isolated module, independent review, state/reconciliation and exchange conformance tests; this app contains none.
