# Honest delivery status

This is an independently written **0.1.0 paper research MVP**, not the complete requested production product or a feature-identical port.

| Area | Delivered | Remaining / qualification |
|---|---|---|
| Flutter/Dart/Riverpod | Native mobile project, feature-first layers | No desktop code embedded |
| Android | ARM64 release-mode APK, local test signature | No physical-device installation test; not store-signed |
| iOS | Runner project + portable application code, manual CI workflow | Xcode build, signing, Keychain/device QA not executed here |
| Dashboard/markets/watchlist | Five tabs, search, persistent stars, real public feeds | Market list currently displays top 150 matching assets |
| Chart | Candles, volume, EMA20, pinch, pan, long-press OHLC | Not a full professional drawing/overlay platform |
| Indicators | EMA/SMA/RSI/MACD/ATR/BB/ADX/VWAP/Stochastic | Numerical outputs; only EMA20 overlay |
| Structure/SR/regime | Closed-candle, rolling SR and ADX-based regime | Smaller research model than upstream |
| Signals/MTF | LONG/SHORT/WAIT, confidence, higher TF confirmation | Full seven-strategy/intelligent evidence parity remains |
| Prediction | Explicitly marked unavailable | Trained multi-horizon forecasts/calibration not implemented |
| Paper/risk/positions | Transactional order FSM, fees, SL, 3 TP, partial/full close, history/PnL | Foreground/current-exchange monitoring; no automatic entries, real wallets or funding |
| Backtest | Next-open, adverse costs, stop-first, last <=500 candles | Historical pagination/import, parameter selection and portfolio simulation remain |
| Walk-forward | Expanding chronological folds, frozen-model train/test report | Not optimized or fully equivalent to live MTF model |
| Historical edge/learning | Min 30 samples, beta shrinkage, Wilson bounds on research returns | No adaptive production weights or regime-bucket performance learner |
| Notification | Durable execution activity list + in-app unread badge | OS notifications, push/background service not implemented |
| AI assistant | Real opt-in OpenAI-compatible HTTPS request, secure key, user question + public context only | Provider credentials required; no live provider-generation test performed; no autonomous tools |
| LBank/Toobit | Real REST + WS public adapters; both probed | Regional/network limitations still possible; not futures execution data |
| KCEX | Explicitly unavailable | Needs verified official API contract; not a fake adapter |
| Security | Secure Storage, no keys in SQLite/source/logs, backups disabled, no order/withdraw API | Device security audit / iOS entitlements verification remain |
| Stability | Retry limits, WS reconnect/resubscribe, heartbeat/watchdog, timeout, cooldown, bounded cache, lifecycle disposal | No claim of absolute crash/leak freedom; long soak/device tests remain |

## Required next milestones
1. Device/emulator E2E, iOS build/signing, Keychain/Keystore tests, battery/memory soak and accessibility at large text scales.
2. Exchange-scoped multi-position stream supervisor; explicit monitoring pause/resume reconciliation; OS notifications.
3. Full reference regression fixtures and seven-strategy evidence port; validated probabilistic forecasting; regime-bucket performance learning.
4. Paginated historical datasets, MTF backtest equivalence, walk-forward model selection and calibration.
5. KCEX only after documented, permitted API verification. Live remains disabled in all milestones until separately authorized and audited.
