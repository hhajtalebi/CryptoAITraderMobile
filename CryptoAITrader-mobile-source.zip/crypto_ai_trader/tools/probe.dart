import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:crypto_ai_trader/features/market/data/exchanges.dart';
import 'package:crypto_ai_trader/core/data/transport.dart';

Future<void> main() async {
  final report = <String, dynamic>{
    'testedAt': DateTime.now().toUtc().toIso8601String(),
  };
  for (final id in ['Toobit', 'LBank']) {
    final api = PublicExchange(id);
    final entry = <String, dynamic>{};
    try {
      final rows = await api.tickers();
      final btc = rows.firstWhere((q) => q.symbol == 'BTC/USDT');
      entry['tickers'] = rows.length;
      entry['btc'] = btc.toJson();
      final candles = await api.candles('BTC/USDT', '1h');
      entry['candles'] = candles.length;
      entry['firstCandle'] = candles.first.time;
      entry['lastCandle'] = candles.last.time;
      if (id == 'Toobit') {
        await File('test/fixtures/public_snapshot.json').writeAsString(
          jsonEncode({
            'quotes': rows.take(15).map((q) => q.toJson()).toList(),
            'candles': candles.map((c) => c.toJson()).toList(),
            'capturedAt': DateTime.now().toUtc().toIso8601String(),
          }),
        );
      }
    } catch (e) {
      entry['restError'] = '$e';
    } finally {
      api.dispose();
    }
    final received = Completer<Map<String, dynamic>>();
    final socket = ResilientSocket(
      url: id == 'Toobit'
          ? 'wss://stream.toobit.com/quote/ws/v1'
          : 'wss://api.lbank.info/ws/V2/',
      subscriptions: [
        id == 'Toobit'
            ? {
                'symbol': 'BTCUSDT',
                'topic': 'realtimes',
                'event': 'sub',
                'params': {'binary': false},
              }
            : {'action': 'subscribe', 'subscribe': 'tick', 'pair': 'btc_usdt'},
      ],
      onMessage: (m) {
        if ((m.containsKey('data') || m.containsKey('tick')) &&
            !received.isCompleted) {
          received.complete(m);
        }
      },
      onStatus: (_) {},
    );
    await socket.start();
    try {
      entry['wsFrame'] = await received.future.timeout(
        const Duration(seconds: 20),
      );
    } catch (_) {
      entry['wsError'] = 'No data frame within 20 seconds';
    } finally {
      socket.dispose();
    }
    report[id] = entry;
  }
  await File(
    'docs/LIVE_PROBE.json',
  ).writeAsString(const JsonEncoder.withIndent('  ').convert(report));
  stdout.writeln(const JsonEncoder.withIndent('  ').convert(report));
}
